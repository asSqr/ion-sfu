This vendor directory contains a copy of golang.org/misc/wasm/ used to
run WASM code in a browser. It was taken from the release version of
go 1.12 (05e77d41914d247a1e7caf37d7125ccaa5a53505).
