# data-channels-close
data-channels-close is a variant of the data-channels example that allow playing with the life cycle of data channels.
