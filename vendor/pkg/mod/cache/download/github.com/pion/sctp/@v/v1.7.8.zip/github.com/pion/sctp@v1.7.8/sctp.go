// Package sctp implements the SCTP spec
package sctp
