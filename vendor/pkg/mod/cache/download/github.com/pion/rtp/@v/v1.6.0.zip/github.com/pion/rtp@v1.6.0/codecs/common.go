package codecs

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
