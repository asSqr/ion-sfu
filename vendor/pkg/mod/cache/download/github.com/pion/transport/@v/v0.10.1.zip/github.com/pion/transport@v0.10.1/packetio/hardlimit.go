// +build packetioSizeHardlimit

package packetio

const sizeHardlimit = true
