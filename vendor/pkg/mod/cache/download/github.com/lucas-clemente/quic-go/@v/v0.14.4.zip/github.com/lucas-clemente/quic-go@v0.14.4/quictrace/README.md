# quic-trace Adapter

This is an experimental implementation of the log format consumed by [quic-trace](https://github.com/google/quic-trace).

At this moment, this package comes with no API stability whatsoever.
